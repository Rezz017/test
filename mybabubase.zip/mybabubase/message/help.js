exports.menu = (prefix, emote) => {
    return `❐──➨ *「 𝑰𝒏𝒇𝒐 𝒎𝒆𝒏𝒖 」*
${emote} cekprefix
${emote} ${prefix}infobot
${emote} ${prefix}stast
${emote} ${prefix}update
${emote} ${prefix}allmenu
${emote} ${prefix}limit
${emote} ${prefix}glimit
${emote} ${prefix}buylimit <angka>
${emote} ${prefix}buyglimit <angka>
${emote} ${prefix}balance
${emote} ${prefix}runtime
${emote} ${prefix}speed
${emote} ${prefix}owner
${emote} ${prefix}donasi
${emote} ${prefix}rules
${emote} ${prefix}patnert
${emote} ${prefix}report <bug nya>
${emote} ${prefix}sourcecode
${emote} ${prefix}listpremium
${emote} ${prefix}tagme
${emote} ${prefix}listban
${emote} ${prefix}listbot
${emote} ${prefix}topbalance
${emote} ${prefix}userbot
${emote} ${prefix}globalbalance
${emote} ${prefix}snk

❐──➨ *「 𝑻𝒐𝒐𝒍𝒔 」*
${emote} ${prefix}sticker
${emote} ${prefix}swm
${emote} ${prefix}take
${emote} ${prefix}kontak nomor|nama
${emote} ${prefix}toimg
${emote} ${prefix}attp text
${emote} ${prefix}amongus text
${emote} ${prefix}codetext text
${emote} ${prefix}tinyurl url
${emote} ${prefix}nulis text
${emote} ${prefix}nuliskiri text
${emote} ${prefix}nuliskanan text
${emote} ${prefix}foliokiri text
${emote} ${prefix}foliokanan text
${emote} ${prefix}translate kodebahasa teks/reply

❐──➨ *「 𝑮𝒓𝒖𝒑 」*
${emote} ${prefix}afk
${emote} ${prefix}infogrup
${emote} ${prefix}chatinfo
${emote} ${prefix}add 628xx
${emote} ${prefix}kick @tag
${emote} ${prefix}promote @tag
${emote} ${prefix}demote @tag
${emote} ${prefix}linkgc
${emote} ${prefix}leave
${emote} ${prefix}setdesc
${emote} ${prefix}setgrupname
${emote} ${prefix}setppgrup
${emote} ${prefix}opengrup
${emote} ${prefix}closegrup
${emote} ${prefix}join
${emote} ${prefix}tagall
${emote} ${prefix}getpic
${emote} ${prefix}hidetag
${emote} ${prefix}tagall
${emote} ${prefix}mute
${emote} ${prefix}unmute
${emote} ${prefix}antilink
${emote} ${prefix}antivo
${emote} ${prefix}welcome
${emote} ${prefix}left
${emote} ${prefix}antibadword
${emote} ${prefix}listbadword
${emote} ${prefix}addbadword
${emote} ${prefix}delbadword
 
❐──➨ *「 𝑫𝒐𝒘𝒏𝒍𝒐𝒂𝒅 」*
${emote} ${prefix}ytmp4 url
${emote} ${prefix}ytmp3 url
${emote} ${prefix}igdl url
${emote} ${prefix}fbdl url
${emote} ${prefix}gogimage query
${emote} ${prefix}tiktok url
${emote} ${prefix}yts query
${emote} ${prefix}play query
${emote} ${prefix}playmp4 query
${emote} ${prefix}igstalk username
${emote} ${prefix}ghstalk username
 
❐──➨ *「 𝑺𝒕𝒊𝒄𝒌 𝒄𝒎𝒅 」*
${emote} ${prefix}setcmd
${emote} ${prefix}delcmd

❐──➨ *「 𝑴𝒂𝒌𝒆𝒓 」*
${emote} ${prefix}blackpink text
${emote} ${prefix}tahta text
${emote} ${prefix}neon text
${emote} ${prefix}glitch text1|text2
${emote} ${prefix}thundername text
${emote} ${prefix}pornhub text1|text2
${emote} ${prefix}freefire text
${emote} ${prefix}horor text 
${emote} ${prefix}joker text
${emote} ${prefix}magma text
${emote} ${prefix}grafity text
${emote} ${prefix}tahtamaker text


❐──➨ *「 𝑴𝒖𝒍𝒕𝒊 𝒔𝒆𝒔𝒔𝒊𝒐𝒏 」*
${emote} ${prefix}jadibot
${emote} ${prefix}getcode
${emote} ${prefix}stopjadibot

❐──➨ *「 𝑭𝒖𝒏 𝒎𝒆𝒏𝒖 」*
${emote} ${prefix}jadian
${emote} ${prefix}ganteng
${emote} ${prefix}cantik
${emote} ${prefix}cariteman 
${emote} ${prefix}tictactoe @tag
${emote} ${prefix}tebakgambar
${emote} ${prefix}family100
${emote} ${prefix}kuis
${emote} ${prefix}suit
${emote} ${prefix}apakah
${emote} ${prefix}bisakah
${emote} ${prefix}kapankah
${emote} ${prefix}hobby
${emote} ${prefix}rate
${emote} ${prefix}tangtangan
${emote} ${prefix}cekbapak
${emote} ${prefix}seberapagay

❐──➨ *「 𝑹𝒂𝒏𝒅𝒐𝒎 𝒎𝒆𝒏𝒖 」*
${emote} ${prefix}wallpaper
${emote} ${prefix}bts
${emote} ${prefix}hentai
${emote} ${prefix}pantun
${emote} ${prefix}katabijak
 
❐──➨ *「 𝑴𝒆𝒏𝒈 𝒘𝒊𝒃𝒖 」*
${emote} ${prefix}waifu
${emote} ${prefix}loli
${emote} ${prefix}nekonime
${emote} ${prefix}megumin
${emote} ${prefix}sagiri
${emote} ${prefix}shinobu`
}
exports.ownerr = (prefix, owner, emote) => {
     return `❐──➨ *「 𝑶𝒘𝒏𝒆𝒓 」*
${emote} > eval
${emote} $ execot
${emote} ${prefix}self
${emote} ${prefix}public
${emote} ${prefix}restart
${emote} ${prefix}off
${emote} ${prefix}addupdate
${emote} ${prefix}resetlimit
${emote} ${prefix}setpp
${emote} ${prefix}setname
${emote} ${prefix}setbio
${emote} ${prefix}setprefix
${emote} ${prefix}bc
${emote} ${prefix}bcbuton
${emote} ${prefix}block
${emote} ${prefix}unblock
${emote} ${prefix}ban
${emote} ${prefix}unban
${emote} ${prefix}clearall
${emote} ${prefix}givelimit
${emote} ${prefix}giveglimit
${emote} ${prefix}exif nama|author
${emote} ${prefix}addsewa link waktu
${emote} ${prefix}delsewa idgroup
${emote} ${prefix}addprem
${emote} ${prefix}delprem`}

exports.infobot = (botName, pendaftar) => {
     return `*Information Bot WhatsApp*
• *Bot name* : _${botName}_
• *Number* :  @62813345116361
• *owner name* : _Reza Dinata_
• *Number* : @6283193164235
• *Total users* : ${pendaftar.length} _Users_
• *Github* : https://github.com/Rezadinata
`}


exports.help = (ucapanWaktu, sender, email, owner, ig) => {
     return `${ucapanWaktu} @${sender.split("@")[0]} 👋

💌 Contak personel 
${email}

📎 Instagram
${ig}

👤Creator Bot
@${owner}

📌 Total Fitur 150+

Silahkan pilih info bot saya kak`}

exports.sewa = (ucapanWaktu, botName, owner) => {
return `━━ *「 DIN BOT - INDO 」* ━━

DIN BOT - INDONESIA
└───────
  └ Sticker Maker, membuat sticker dari video atau gambar dalam waktu singkat
  └ Dengan menggunakan Din Bot kamu dapat mendownload video atau audio dari youtube dengan sangat mudah
  └ Dengan menggunakan Din Bot kamu juga dapat mendownload video atau audio dari tiktok dengan sangat mudah

◩ *FREE USER*
└───────
 └✅ Bot on 24 jam 
 └❎ Unlimited Limit
 └❎ Premium User 
 └❎ Add Bot to Group 
   └❏ *Rp. ~0,00~*
 
◩ *PREMIUM*
└───────
 └✅ Bot on 24 jam 
 └✅ Unlimited Limit 
 └✅ Premium User 
 └❎ Add Bot to Group 
   └❏ *Rp. 10.000*
     └ Expired 30h
  
◩ *VIP - USER*
└───────
 └✅ Bot on 24 jam 
 └✅ Unlimited Limit 
 └✅ Premium User 
 └✅ Add Bot to Group 
   └❏ *Rp. 20.000*
     └ Expired 30h

◩ *SO OWNER*
└───────
 └✅ Bot on 24 Jam 
 └✅ Change photos 
 └✅ Replace the boat name 
 └✅ Can be rented 
   └❏ *Rp. 100.000*
     └ Expired 30h 
   
*MINAT CHAT OWNER DIN BOT*
@${owner}
`}
 
exports.rules = (prefix, sender) => {
    return `*── 「 RULES 」 ──*

Hai kak @${sender.split("@")[0]}

1. Jangan spam bot. 
Sanksi: *WARN/SOFT BLOCK*

2. Jangan telepon bot.
Sanksi: *SOFT BLOCK*

3. Jangan mengeksploitasi bot.
Sanksi: *PERMANENT BLOCK*

Jika sudah dipahami rules-nya, silakan ketik *${prefix}menu* untuk memulai!
`}